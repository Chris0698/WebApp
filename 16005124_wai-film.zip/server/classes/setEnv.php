<?php

define("CONFIGLOCATION", "../config.xml");

error_reporting(-1);
ini_set("display_errors", 1);