KF6012 Web App submission.

Used OOPHP classes, they are inside server/classes directory. Webpage class was unused but i think all the others were including FileWriter class to log an exception to a text file for a fun little bonus thing. 

Inside testing for allow a note to be changed or created, for this implementation it will be to create a note for film ID 10. If you click on the view note link, that will show the note been created for ID 10. 

Slight change to the suggested directory structure, it was largely kept as recomended with some changes. The config file that contains the database name in the DNS tags for the connection was at root level and the database itself was kept inside the server directory. 

Not much else i can say really. Stuck to the assignment spec and implemented everything requested. 